﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen line = new Pen(Color.Red);
            Brush rect = new SolidBrush(Color.Green);
            Brush circle = new SolidBrush(Color.Yellow);
            Brush point = new SolidBrush(Color.Blue);
            g.FillRectangle(rect, 60, 60, 100, 50);                  //Drawing a Rectangle
            g.FillEllipse(circle, 10, 10, 50, 50);                 //Drawing a Circle
            g.DrawLine(line, new PointF(100, 200), new PointF(100, 240));       //Drawing a Line
            g.FillEllipse(point, 200, 200, 4, 4);                           //Drawing a Point 
        }
    }
}
